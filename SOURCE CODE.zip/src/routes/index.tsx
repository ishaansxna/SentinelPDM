import { createFileRoute } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  ReferenceLine,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  Cpu,
  Database,
  Download,
  FileText,
  Gauge,
  Pause,
  Play,
  Radio,
  RotateCcw,
  ShieldAlert,
  Smartphone,
  Thermometer,
  Upload,
  Waves,
  Wrench,
  Zap,
} from "lucide-react";
import { toast } from "sonner";
import {
  FLEET,
  featureImportance,
  forecastRisk,
  generateSeries,
  hoursToFailure,
  recommend,
  scoreSeries,
  type Equipment,
  type Reading,
  type Scored,
} from "@/lib/pdm";
import { buildMaintenanceReport } from "@/lib/report";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SentinelPdM — Offline Predictive Maintenance" },
      {
        name: "description",
        content:
          "Offline predictive maintenance dashboard for industrial equipment. Sensor telemetry, failure risk scoring, feature importance, dataset upload and PDF-ready reports.",
      },
      { property: "og:title", content: "SentinelPdM — Offline Predictive Maintenance" },
      {
        property: "og:description",
        content:
          "Offline predictive maintenance dashboard for industrial equipment. Sensor telemetry, failure risk scoring, feature importance, dataset upload and PDF-ready reports.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Dashboard,
});

type AssetState = { readings: Reading[]; source: "synthetic" | "uploaded" };

function Dashboard() {
  const [selectedId, setSelectedId] = useState<string>(FLEET[0].id);
  const [horizon, setHorizon] = useState(72);
  const [threshold, setThreshold] = useState(75);
  const [liveMode, setLiveMode] = useState(false);
  const [assets, setAssets] = useState<Record<string, AssetState>>(() =>
    Object.fromEntries(
      FLEET.map((eq) => [eq.id, { readings: generateSeries(eq, 720, 7), source: "synthetic" as const }]),
    ),
  );
  const [installEvent, setInstallEvent] = useState<any>(null);
  const [installState, setInstallState] = useState<"available" | "installed" | "unavailable">("unavailable");

  // PWA install prompt capture
  useEffect(() => {
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setInstallEvent(e);
      setInstallState("available");
    };
    const onInstalled = () => setInstallState("installed");
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    if (window.matchMedia?.("(display-mode: standalone)").matches) setInstallState("installed");
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  // Live simulation: append a synthetic new hour every 1.2s to the selected asset
  useEffect(() => {
    if (!liveMode) return;
    const id = setInterval(() => {
      setAssets((prev) => {
        const cur = prev[selectedId];
        if (!cur) return prev;
        const last = cur.readings[cur.readings.length - 1];
        const jitter = () => (Math.random() - 0.5) * 2;
        const drift = 1.002;
        const next: Reading = {
          t: last.t + 1,
          runtimeHours: last.runtimeHours + 1,
          vibration: +(last.vibration * drift + jitter() * 0.25).toFixed(2),
          temperature: +(last.temperature * 1.0008 + jitter() * 0.7).toFixed(1),
          pressure: +(last.pressure + jitter() * 0.08).toFixed(2),
          rpm: Math.round(last.rpm + jitter() * 5),
          current: +(last.current * 1.0006 + jitter() * 0.35).toFixed(1),
          oilQuality: +Math.max(0, last.oilQuality - 0.03 + jitter() * 0.1).toFixed(1),
        };
        return {
          ...prev,
          [selectedId]: { ...cur, readings: [...cur.readings.slice(-1000), next] },
        };
      });
    }, 1200);
    return () => clearInterval(id);
  }, [liveMode, selectedId]);

  const fleetData = useMemo(
    () =>
      FLEET.map((eq) => {
        const readings = assets[eq.id]?.readings ?? generateSeries(eq, 720, 7);
        const scored = scoreSeries(readings, eq);
        const forecast = forecastRisk(scored, 168);
        const htf = hoursToFailure(forecast, threshold / 100);
        return { eq, scored, forecast, htf, current: scored[scored.length - 1], source: assets[eq.id]?.source ?? "synthetic" };
      }),
    [assets, threshold],
  );

  const selected = fleetData.find((f) => f.eq.id === selectedId)!;
  const importance = featureImportance(selected.current, selected.eq);
  const recs = recommend(selected.scored, selected.eq);

  const forecastCut = selected.forecast.slice(0, horizon);
  const chartData = [
    ...selected.scored.slice(-120).map((r) => ({ t: r.t, actual: +(r.risk * 100).toFixed(1), forecast: null as number | null })),
    ...forecastCut.map((f) => ({ t: f.hour, actual: null as number | null, forecast: +(f.risk * 100).toFixed(1) })),
  ];

  const sensorData = selected.scored.slice(-120).map((r) => ({
    t: r.t,
    vibration: r.vibration,
    temperature: r.temperature,
    current: r.current,
    oilQuality: r.oilQuality,
  }));

  const critical = fleetData.filter((f) => f.current.risk > 0.6).length;
  const warning = fleetData.filter((f) => f.current.risk > 0.3 && f.current.risk <= 0.6).length;
  const healthy = fleetData.length - critical - warning;
  const avgRisk = fleetData.reduce((s, f) => s + f.current.risk, 0) / fleetData.length;

  const exportCsv = () => {
    const rows = [
      "hour,vibration_mm_s,temperature_c,pressure_bar,rpm,current_a,oil_quality,risk,label",
      ...selected.scored.map((r) =>
        [r.t, r.vibration, r.temperature, r.pressure, r.rpm, r.current, r.oilQuality, r.risk.toFixed(4), r.label].join(","),
      ),
    ].join("\n");
    downloadBlob(rows, `${selected.eq.id}-telemetry.csv`, "text/csv");
    toast.success("CSV downloaded");
  };

  const exportReport = () => {
    const html = buildMaintenanceReport({
      eq: selected.eq,
      scored: selected.scored,
      forecast: selected.forecast,
      importance,
      recs,
      htf: selected.htf,
      threshold: threshold / 100,
    });
    downloadBlob(html, `${selected.eq.id}-maintenance-report.html`, "text/html");
    toast.success("Maintenance report generated");
  };

  const handleUpload = useCallback(
    async (file: File) => {
      try {
        const text = await file.text();
        const parsed = parseCsv(text);
        if (parsed.length < 10) {
          toast.error("CSV needs at least 10 rows with sensor columns");
          return;
        }
        setAssets((prev) => ({
          ...prev,
          [selectedId]: { readings: parsed, source: "uploaded" },
        }));
        toast.success(`Loaded ${parsed.length} readings into ${selected.eq.name}`);
      } catch (e: any) {
        toast.error(`Upload failed: ${e.message ?? "invalid CSV"}`);
      }
    },
    [selectedId, selected.eq.name],
  );

  const resetAsset = () => {
    setAssets((prev) => ({
      ...prev,
      [selectedId]: { readings: generateSeries(selected.eq, 720, 7), source: "synthetic" },
    }));
    toast("Restored synthetic dataset");
  };

  const installApp = async () => {
    if (!installEvent) return;
    installEvent.prompt();
    const res = await installEvent.userChoice;
    if (res?.outcome === "accepted") {
      setInstallState("installed");
      toast.success("App installed");
    }
    setInstallEvent(null);
  };

  return (
    <div className="min-h-screen grid-bg">
      <div className="mx-auto max-w-[1400px] px-4 py-6 sm:px-6 sm:py-8">
        <Header
          critical={critical}
          installState={installState}
          onInstall={installApp}
          liveMode={liveMode}
          onToggleLive={() => setLiveMode((v) => !v)}
        />

        <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
          <Kpi icon={<Database className="h-4 w-4" />} label="Assets Monitored" value={String(FLEET.length)} sub="Live sensor streams" />
          <Kpi
            icon={<CheckCircle2 className="h-4 w-4 text-[color:var(--success)]" />}
            label="Healthy"
            value={String(healthy)}
            sub={`${warning} warning · ${critical} critical`}
            accent="success"
          />
          <Kpi
            icon={<ShieldAlert className="h-4 w-4 text-[color:var(--warning)]" />}
            label="Fleet Risk"
            value={`${(avgRisk * 100).toFixed(0)}%`}
            sub="Weighted mean failure probability"
            accent={avgRisk > 0.5 ? "danger" : avgRisk > 0.3 ? "warning" : "success"}
          />
          <Kpi icon={<Cpu className="h-4 w-4" />} label="Model" value="LGR-v2.1" sub="6 features · offline inference" />
        </div>

        <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-[320px_1fr]">
          <FleetList data={fleetData} selectedId={selectedId} onSelect={setSelectedId} threshold={threshold / 100} />

          <div className="space-y-6">
            <AssetHeader
              eq={selected.eq}
              risk={selected.current.risk}
              htf={selected.htf}
              source={selected.source}
              onExportCsv={exportCsv}
              onExportReport={exportReport}
              onUpload={handleUpload}
              onReset={resetAsset}
              liveMode={liveMode}
            />

            <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
              <SensorTile icon={<Waves />} label="Vibration" value={selected.current.vibration} unit="mm/s" />
              <SensorTile icon={<Thermometer />} label="Temperature" value={selected.current.temperature} unit="°C" />
              <SensorTile icon={<Zap />} label="Current" value={selected.current.current} unit="A" />
              <SensorTile icon={<Gauge />} label="Oil Quality" value={selected.current.oilQuality} unit="%" />
            </div>

            <Panel title="Failure Risk — actual & forecast" icon={<Activity className="h-4 w-4" />}>
              <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  {[24, 72, 168].map((h) => (
                    <button
                      key={h}
                      onClick={() => setHorizon(h)}
                      className={`mono rounded-md border px-3 py-1 text-xs transition ${
                        horizon === h
                          ? "border-primary bg-primary/15 text-primary"
                          : "border-border text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      +{h}h
                    </button>
                  ))}
                </div>
                <label className="flex items-center gap-3">
                  <span className="mono text-[10px] uppercase tracking-wider text-muted-foreground">
                    Alert threshold
                  </span>
                  <input
                    type="range"
                    min={30}
                    max={95}
                    value={threshold}
                    onChange={(e) => setThreshold(Number(e.target.value))}
                    className="w-32 accent-[color:var(--primary)]"
                  />
                  <span className="mono w-10 text-right text-xs text-primary">{threshold}%</span>
                </label>
              </div>
              <ResponsiveContainer width="100%" height={260}>
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="gActual" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0%" stopColor="var(--chart-2)" stopOpacity={0.6} />
                      <stop offset="100%" stopColor="var(--chart-2)" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="gForecast" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0%" stopColor="var(--chart-1)" stopOpacity={0.6} />
                      <stop offset="100%" stopColor="var(--chart-1)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid stroke="oklch(1 0 0 / 0.05)" vertical={false} />
                  <XAxis dataKey="t" stroke="var(--muted-foreground)" fontSize={11} />
                  <YAxis stroke="var(--muted-foreground)" fontSize={11} domain={[0, 100]} unit="%" />
                  <Tooltip content={<ChartTooltip />} />
                  <ReferenceLine y={threshold} stroke="var(--destructive)" strokeDasharray="4 4" label={{ value: `${threshold}%`, fill: "var(--destructive)", fontSize: 10, position: "right" }} />
                  <Area type="monotone" dataKey="actual" stroke="var(--chart-2)" fill="url(#gActual)" strokeWidth={2} isAnimationActive={false} />
                  <Area type="monotone" dataKey="forecast" stroke="var(--chart-1)" fill="url(#gForecast)" strokeWidth={2} strokeDasharray="5 4" isAnimationActive={false} />
                </AreaChart>
              </ResponsiveContainer>
            </Panel>

            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              <Panel title="Sensor telemetry" icon={<Radio className="h-4 w-4" />}>
                <ResponsiveContainer width="100%" height={220}>
                  <LineChart data={sensorData}>
                    <CartesianGrid stroke="oklch(1 0 0 / 0.05)" vertical={false} />
                    <XAxis dataKey="t" stroke="var(--muted-foreground)" fontSize={10} />
                    <YAxis stroke="var(--muted-foreground)" fontSize={10} />
                    <Tooltip content={<ChartTooltip />} />
                    <Line type="monotone" dataKey="vibration" stroke="var(--chart-1)" strokeWidth={1.5} dot={false} isAnimationActive={false} />
                    <Line type="monotone" dataKey="temperature" stroke="var(--chart-2)" strokeWidth={1.5} dot={false} isAnimationActive={false} />
                    <Line type="monotone" dataKey="current" stroke="var(--chart-3)" strokeWidth={1.5} dot={false} isAnimationActive={false} />
                    <Line type="monotone" dataKey="oilQuality" stroke="var(--chart-4)" strokeWidth={1.5} dot={false} isAnimationActive={false} />
                  </LineChart>
                </ResponsiveContainer>
                <Legend
                  items={[
                    { c: "var(--chart-1)", l: "Vibration" },
                    { c: "var(--chart-2)", l: "Temperature" },
                    { c: "var(--chart-3)", l: "Current" },
                    { c: "var(--chart-4)", l: "Oil Quality" },
                  ]}
                />
              </Panel>

              <Panel title="Feature contribution to risk" icon={<Cpu className="h-4 w-4" />}>
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={importance} layout="vertical" margin={{ left: 20 }}>
                    <CartesianGrid stroke="oklch(1 0 0 / 0.05)" horizontal={false} />
                    <XAxis type="number" stroke="var(--muted-foreground)" fontSize={10} />
                    <YAxis type="category" dataKey="feature" stroke="var(--muted-foreground)" fontSize={11} width={90} />
                    <Tooltip content={<ChartTooltip />} />
                    <Bar dataKey="contribution" radius={[0, 4, 4, 0]} isAnimationActive={false}>
                      {importance.map((_, i) => (
                        <Cell key={i} fill={i === 0 ? "var(--destructive)" : i === 1 ? "var(--warning)" : "var(--chart-2)"} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </Panel>
            </div>

            <Panel title="Recommended actions" icon={<Wrench className="h-4 w-4" />}>
              <ul className="space-y-2">
                {recs.map((r, i) => (
                  <li key={i} className="flex items-start gap-3 rounded-md border border-border/60 bg-background/40 p-3">
                    <span className="mono mt-0.5 rounded bg-primary/15 px-1.5 py-0.5 text-[10px] text-primary">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span className="text-sm text-foreground/90">{r}</span>
                  </li>
                ))}
              </ul>
            </Panel>

            <Footer />
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------- CSV parsing ---------- */

function parseCsv(text: string): Reading[] {
  const lines = text.trim().split(/\r?\n/).filter(Boolean);
  const header = lines[0].split(",").map((h) => h.trim().toLowerCase());
  const idx = (names: string[]) => {
    for (const n of names) {
      const i = header.indexOf(n);
      if (i !== -1) return i;
    }
    return -1;
  };
  const cVib = idx(["vibration", "vibration_mm_s", "vib"]);
  const cTmp = idx(["temperature", "temperature_c", "temp"]);
  const cPre = idx(["pressure", "pressure_bar"]);
  const cRpm = idx(["rpm", "speed"]);
  const cCur = idx(["current", "current_a", "amps"]);
  const cOil = idx(["oil_quality", "oil", "oilquality"]);

  if ([cVib, cTmp, cPre, cRpm, cCur, cOil].some((i) => i === -1)) {
    throw new Error("required columns: vibration, temperature, pressure, rpm, current, oil_quality");
  }

  return lines.slice(1).map((line, i) => {
    const c = line.split(",");
    const num = (j: number) => Number(c[j]);
    return {
      t: i,
      runtimeHours: i,
      vibration: num(cVib),
      temperature: num(cTmp),
      pressure: num(cPre),
      rpm: num(cRpm),
      current: num(cCur),
      oilQuality: num(cOil),
    };
  });
}

function downloadBlob(content: string, filename: string, mime: string) {
  const url = URL.createObjectURL(new Blob([content], { type: mime }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

/* ---------- UI subcomponents ---------- */

function Header({
  critical,
  installState,
  onInstall,
  liveMode,
  onToggleLive,
}: {
  critical: number;
  installState: "available" | "installed" | "unavailable";
  onInstall: () => void;
  liveMode: boolean;
  onToggleLive: () => void;
}) {
  return (
    <header className="flex flex-wrap items-center justify-between gap-4 border-b border-border pb-6">
      <div className="flex items-center gap-3">
        <div className="relative flex h-10 w-10 items-center justify-center rounded-lg bg-primary/15 ring-1 ring-primary/30">
          <ShieldAlert className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h1 className="text-xl font-semibold tracking-tight">
            SentinelPdM<span className="text-primary">.</span>
          </h1>
          <p className="mono text-xs text-muted-foreground">
            offline predictive maintenance · industrial equipment
          </p>
        </div>
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2 rounded-md border border-border bg-background/40 px-3 py-1.5">
          <span className={`h-2 w-2 rounded-full ${critical === 0 ? "bg-[color:var(--success)] pulse-dot" : "bg-destructive pulse-dot"}`} />
          <span className="mono text-[10px] uppercase tracking-wider text-muted-foreground">
            {critical === 0 ? "All systems nominal" : `${critical} at risk`}
          </span>
        </div>

        <button
          onClick={onToggleLive}
          className={`mono flex items-center gap-2 rounded-md border px-3 py-1.5 text-xs transition ${
            liveMode
              ? "border-[color:var(--success)]/50 bg-[color:var(--success)]/10 text-[color:var(--success)]"
              : "border-border bg-background/40 text-muted-foreground hover:text-foreground"
          }`}
        >
          {liveMode ? <Pause className="h-3.5 w-3.5" /> : <Play className="h-3.5 w-3.5" />}
          {liveMode ? "Live · streaming" : "Simulate live"}
        </button>

        {installState === "available" ? (
          <button
            onClick={onInstall}
            className="mono flex items-center gap-2 rounded-md border border-primary bg-primary/15 px-3 py-1.5 text-xs text-primary transition hover:bg-primary/25"
          >
            <Smartphone className="h-3.5 w-3.5" /> Install app
          </button>
        ) : installState === "installed" ? (
          <span className="mono flex items-center gap-2 rounded-md border border-[color:var(--success)]/40 bg-[color:var(--success)]/10 px-3 py-1.5 text-xs text-[color:var(--success)]">
            <CheckCircle2 className="h-3.5 w-3.5" /> Installed
          </span>
        ) : null}
      </div>
    </header>
  );
}

function Kpi({
  icon,
  label,
  value,
  sub,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub: string;
  accent?: "success" | "warning" | "danger";
}) {
  const accentColor =
    accent === "danger"
      ? "text-destructive"
      : accent === "warning"
        ? "text-[color:var(--warning)]"
        : accent === "success"
          ? "text-[color:var(--success)]"
          : "text-foreground";
  return (
    <div className="panel p-4 md:p-5">
      <div className="flex items-center justify-between text-muted-foreground">
        <span className="mono text-[10px] uppercase tracking-wider">{label}</span>
        {icon}
      </div>
      <div className={`mono mt-3 text-2xl font-semibold md:text-3xl ${accentColor}`}>{value}</div>
      <div className="mt-1 text-xs text-muted-foreground">{sub}</div>
    </div>
  );
}

function FleetList({
  data,
  selectedId,
  onSelect,
  threshold,
}: {
  data: { eq: Equipment; current: { risk: number }; htf: number | null; source: "synthetic" | "uploaded" }[];
  selectedId: string;
  onSelect: (id: string) => void;
  threshold: number;
}) {
  return (
    <div className="panel p-4">
      <div className="mono mb-3 flex items-center justify-between text-[10px] uppercase tracking-wider text-muted-foreground">
        <span>Fleet</span>
        <span>{data.length} assets · @{Math.round(threshold * 100)}%</span>
      </div>
      <div className="space-y-2">
        {data.map(({ eq, current, htf, source }) => {
          const risk = current.risk;
          const isSel = eq.id === selectedId;
          const tier = risk > 0.6 ? "danger" : risk > 0.3 ? "warning" : "success";
          const dotColor =
            tier === "danger" ? "bg-destructive" : tier === "warning" ? "bg-[color:var(--warning)]" : "bg-[color:var(--success)]";
          return (
            <button
              key={eq.id}
              onClick={() => onSelect(eq.id)}
              className={`w-full rounded-md border p-3 text-left transition ${
                isSel
                  ? "border-primary/50 bg-primary/5"
                  : "border-border/60 bg-background/30 hover:border-border hover:bg-background/60"
              }`}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className={`h-2 w-2 rounded-full ${dotColor} ${tier === "danger" ? "pulse-dot" : ""}`} />
                  <span className="mono text-xs text-muted-foreground">{eq.id}</span>
                  {source === "uploaded" ? (
                    <span className="mono rounded bg-accent/15 px-1 py-0.5 text-[9px] text-accent">CSV</span>
                  ) : null}
                </div>
                <span className="mono text-xs text-foreground/80">{(risk * 100).toFixed(0)}%</span>
              </div>
              <div className="mt-1 text-sm font-medium">{eq.name}</div>
              <div className="mono mt-1 flex items-center justify-between text-[10px] text-muted-foreground">
                <span>
                  {eq.type} · {eq.installedYears}y
                </span>
                <span>{htf ? `TTF ~${htf}h` : "stable"}</span>
              </div>
              <div className="mt-2 h-1 overflow-hidden rounded bg-background/60">
                <div
                  className={`h-full transition-all ${
                    tier === "danger" ? "bg-destructive" : tier === "warning" ? "bg-[color:var(--warning)]" : "bg-[color:var(--success)]"
                  }`}
                  style={{ width: `${Math.min(100, risk * 100)}%` }}
                />
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function AssetHeader({
  eq,
  risk,
  htf,
  source,
  onExportCsv,
  onExportReport,
  onUpload,
  onReset,
  liveMode,
}: {
  eq: Equipment;
  risk: number;
  htf: number | null;
  source: "synthetic" | "uploaded";
  onExportCsv: () => void;
  onExportReport: () => void;
  onUpload: (f: File) => void;
  onReset: () => void;
  liveMode: boolean;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const tier = risk > 0.6 ? "CRITICAL" : risk > 0.3 ? "WARNING" : "HEALTHY";
  const tierColor =
    risk > 0.6
      ? "text-destructive border-destructive/40 bg-destructive/10"
      : risk > 0.3
        ? "text-[color:var(--warning)] border-[color:var(--warning)]/40 bg-[color:var(--warning)]/10"
        : "text-[color:var(--success)] border-[color:var(--success)]/40 bg-[color:var(--success)]/10";
  return (
    <div className="panel p-5">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="mono flex items-center gap-2 text-xs text-muted-foreground">
            {eq.id} · {eq.type}
            {source === "uploaded" ? (
              <span className="mono rounded bg-accent/15 px-1.5 py-0.5 text-[9px] text-accent">CSV DATASET</span>
            ) : (
              <span className="mono rounded bg-muted/40 px-1.5 py-0.5 text-[9px]">SYNTHETIC</span>
            )}
            {liveMode ? (
              <span className="mono rounded bg-[color:var(--success)]/15 px-1.5 py-0.5 text-[9px] text-[color:var(--success)]">
                LIVE
              </span>
            ) : null}
          </div>
          <h2 className="mt-1 text-xl font-semibold tracking-tight md:text-2xl">{eq.name}</h2>
          <div className="mono mt-1 text-xs text-muted-foreground">
            Installed {eq.installedYears} years ago · {(eq.installedYears * 8760).toLocaleString()} lifetime hours
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <div className="text-right">
            <div className="mono text-[10px] uppercase tracking-wider text-muted-foreground">Failure Probability</div>
            <div className="mono text-2xl font-semibold md:text-3xl">{(risk * 100).toFixed(1)}%</div>
            <div className="mono text-[10px] text-muted-foreground">
              {htf ? `Est. TTF ~${htf}h` : "Stable trajectory"}
            </div>
          </div>
          <div className={`mono rounded-md border px-3 py-2 text-xs ${tierColor}`}>
            {tier === "CRITICAL" && <AlertTriangle className="mr-1 inline h-3 w-3" />}
            {tier}
          </div>
        </div>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-border pt-4">
        <input
          ref={fileRef}
          type="file"
          accept=".csv,text/csv"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onUpload(f);
            e.target.value = "";
          }}
        />
        <ToolbarButton icon={<Upload className="h-3.5 w-3.5" />} onClick={() => fileRef.current?.click()}>
          Upload CSV
        </ToolbarButton>
        <ToolbarButton icon={<Download className="h-3.5 w-3.5" />} onClick={onExportCsv}>
          Export CSV
        </ToolbarButton>
        <ToolbarButton icon={<FileText className="h-3.5 w-3.5" />} onClick={onExportReport} primary>
          Generate report
        </ToolbarButton>
        {source === "uploaded" ? (
          <ToolbarButton icon={<RotateCcw className="h-3.5 w-3.5" />} onClick={onReset}>
            Restore synthetic
          </ToolbarButton>
        ) : null}
        <div className="mono ml-auto text-[10px] text-muted-foreground">
          CSV columns: vibration, temperature, pressure, rpm, current, oil_quality
        </div>
      </div>
    </div>
  );
}

function ToolbarButton({
  icon,
  children,
  onClick,
  primary,
}: {
  icon: React.ReactNode;
  children: React.ReactNode;
  onClick?: () => void;
  primary?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`mono flex items-center gap-2 rounded-md border px-3 py-1.5 text-xs transition ${
        primary
          ? "border-primary bg-primary/15 text-primary hover:bg-primary/25"
          : "border-border bg-background/40 text-muted-foreground hover:border-primary/40 hover:text-foreground"
      }`}
    >
      {icon}
      {children}
    </button>
  );
}

function SensorTile({
  icon,
  label,
  value,
  unit,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  unit: string;
}) {
  return (
    <div className="panel p-4">
      <div className="flex items-center justify-between text-muted-foreground">
        <span className="mono text-[10px] uppercase tracking-wider">{label}</span>
        <span className="text-primary">{icon}</span>
      </div>
      <div className="mono mt-2 text-2xl font-semibold">
        {value}
        <span className="ml-1 text-xs text-muted-foreground">{unit}</span>
      </div>
    </div>
  );
}

function Panel({
  title,
  icon,
  children,
}: {
  title: string;
  icon?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="panel p-4 md:p-5">
      <div className="mb-4 flex items-center gap-2 text-muted-foreground">
        {icon}
        <h3 className="mono text-[11px] uppercase tracking-wider">{title}</h3>
      </div>
      {children}
    </section>
  );
}

function Legend({ items }: { items: { c: string; l: string }[] }) {
  return (
    <div className="mt-3 flex flex-wrap gap-4">
      {items.map((i) => (
        <div key={i.l} className="flex items-center gap-2">
          <span className="h-2 w-2 rounded-full" style={{ background: i.c }} />
          <span className="mono text-[10px] uppercase tracking-wider text-muted-foreground">{i.l}</span>
        </div>
      ))}
    </div>
  );
}

function ChartTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="panel mono p-2 text-xs">
      <div className="text-muted-foreground">t = {label}</div>
      {payload.map((p: any) => (
        <div key={p.dataKey} className="flex items-center gap-2">
          <span className="h-2 w-2 rounded-full" style={{ background: p.color }} />
          <span className="text-foreground">
            {p.dataKey}: {p.value}
          </span>
        </div>
      ))}
    </div>
  );
}

function Footer() {
  return (
    <footer className="mono border-t border-border pt-4 text-[10px] uppercase tracking-wider text-muted-foreground">
      100% offline in-browser · installable PWA · CSV in / CSV & HTML report out
    </footer>
  );
}

// keep Scored type import referenced
export type _ = Scored;
