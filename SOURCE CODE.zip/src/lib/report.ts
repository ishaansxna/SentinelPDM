import type { Equipment, FeatureImportance, Forecast, Scored } from "./pdm";

export function buildMaintenanceReport(input: {
  eq: Equipment;
  scored: Scored[];
  forecast: Forecast[];
  importance: FeatureImportance[];
  recs: string[];
  htf: number | null;
  threshold: number;
}): string {
  const { eq, scored, forecast, importance, recs, htf, threshold } = input;
  const last = scored[scored.length - 1];
  const window = scored.slice(-168);
  const stats = {
    vib: stat(window.map((r) => r.vibration)),
    tmp: stat(window.map((r) => r.temperature)),
    cur: stat(window.map((r) => r.current)),
    oil: stat(window.map((r) => r.oilQuality)),
    risk: stat(window.map((r) => r.risk)),
  };
  const alerts = window.filter((r) => r.risk >= threshold).length;
  const now = new Date().toISOString().replace("T", " ").slice(0, 16);
  const tier =
    last.risk > 0.6 ? "CRITICAL" : last.risk > 0.3 ? "WARNING" : "HEALTHY";
  const tierColor = last.risk > 0.6 ? "#e05a4d" : last.risk > 0.3 ? "#d99b3a" : "#4bb37b";

  const peakForecast = forecast.reduce((m, f) => (f.risk > m.risk ? f : m), forecast[0]);

  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<title>Maintenance Report — ${escape(eq.name)}</title>
<style>
  :root { --fg:#111; --muted:#666; --bg:#fff; --border:#e5e5e5; --accent:#c26a1f; }
  * { box-sizing: border-box; }
  body { margin:0; padding:40px; font: 14px/1.55 -apple-system, "Segoe UI", Roboto, sans-serif; color:var(--fg); background:var(--bg); }
  header { display:flex; justify-content:space-between; align-items:flex-start; border-bottom:2px solid var(--fg); padding-bottom:16px; margin-bottom:24px; }
  h1 { margin:0; font-size:22px; letter-spacing:-.01em; }
  h2 { font-size:13px; text-transform:uppercase; letter-spacing:.08em; color:var(--muted); margin:32px 0 10px; border-bottom:1px solid var(--border); padding-bottom:6px; }
  .muted { color:var(--muted); font-size:12px; }
  .mono { font-family: ui-monospace, "SF Mono", Menlo, monospace; }
  .badge { display:inline-block; padding:4px 10px; border-radius:4px; font-family: ui-monospace, monospace; font-size:11px; letter-spacing:.05em; color:#fff; background:${tierColor}; }
  table { width:100%; border-collapse:collapse; margin-top:8px; }
  th, td { text-align:left; padding:8px 10px; border-bottom:1px solid var(--border); font-size:13px; }
  th { color:var(--muted); font-weight:600; font-size:11px; text-transform:uppercase; letter-spacing:.05em; }
  td.num, th.num { text-align:right; font-family: ui-monospace, monospace; }
  ol { padding-left:20px; } ol li { margin:6px 0; }
  .grid { display:grid; grid-template-columns: repeat(4, 1fr); gap:12px; margin-top:8px; }
  .card { border:1px solid var(--border); border-radius:6px; padding:12px; }
  .card .k { font-size:11px; color:var(--muted); text-transform:uppercase; letter-spacing:.05em; }
  .card .v { font-family: ui-monospace, monospace; font-size:20px; margin-top:4px; }
  footer { margin-top:40px; padding-top:16px; border-top:1px solid var(--border); font-size:11px; color:var(--muted); }
  @media print { body { padding:24px; } }
</style></head>
<body>
  <header>
    <div>
      <div class="muted mono">${eq.id} · ${eq.type}</div>
      <h1>Maintenance Report — ${escape(eq.name)}</h1>
      <div class="muted">Generated ${now} · SentinelPdM v2.1</div>
    </div>
    <span class="badge">${tier}</span>
  </header>

  <h2>Executive Summary</h2>
  <p>
    Asset <strong>${escape(eq.name)}</strong> (${eq.type}, installed ${eq.installedYears} years ago)
    is currently rated <strong style="color:${tierColor}">${tier}</strong> with a failure
    probability of <strong>${(last.risk * 100).toFixed(1)}%</strong>.
    ${htf ? `Model forecast reaches the ${(threshold * 100).toFixed(0)}% alert threshold in approximately <strong>${htf} hours</strong>.` : "Model forecast remains below the alert threshold in the reviewed horizon."}
    Over the last 168 hours the asset recorded <strong>${alerts}</strong> readings above threshold.
  </p>

  <div class="grid">
    <div class="card"><div class="k">Current Risk</div><div class="v">${(last.risk * 100).toFixed(1)}%</div></div>
    <div class="card"><div class="k">7-day Peak</div><div class="v">${(stats.risk.max * 100).toFixed(1)}%</div></div>
    <div class="card"><div class="k">Forecast Peak</div><div class="v">${(peakForecast.risk * 100).toFixed(1)}%</div></div>
    <div class="card"><div class="k">Threshold Breaches</div><div class="v">${alerts}</div></div>
  </div>

  <h2>Sensor Summary — last 168 hours</h2>
  <table>
    <thead><tr><th>Signal</th><th class="num">Min</th><th class="num">Mean</th><th class="num">Max</th><th class="num">Current</th></tr></thead>
    <tbody>
      ${row("Vibration (mm/s)", stats.vib, last.vibration)}
      ${row("Temperature (°C)", stats.tmp, last.temperature)}
      ${row("Current (A)", stats.cur, last.current)}
      ${row("Oil quality (%)", stats.oil, last.oilQuality)}
    </tbody>
  </table>

  <h2>Feature Contribution</h2>
  <table>
    <thead><tr><th>Feature</th><th class="num">Weight</th><th class="num">Contribution</th></tr></thead>
    <tbody>
      ${importance
        .map(
          (f) => `<tr><td>${escape(f.feature)}</td><td class="num">${f.weight.toFixed(2)}</td><td class="num">${f.contribution.toFixed(2)}</td></tr>`,
        )
        .join("")}
    </tbody>
  </table>

  <h2>Recommended Actions</h2>
  <ol>${recs.map((r) => `<li>${escape(r)}</li>`).join("")}</ol>

  <footer>
    SentinelPdM · offline predictive maintenance report · generated in-browser · deterministic model LGR-v2.1
  </footer>
</body></html>`;
}

function stat(arr: number[]) {
  const min = Math.min(...arr);
  const max = Math.max(...arr);
  const mean = arr.reduce((a, b) => a + b, 0) / (arr.length || 1);
  return { min, max, mean };
}

function row(label: string, s: { min: number; mean: number; max: number }, current: number) {
  return `<tr><td>${label}</td><td class="num">${s.min.toFixed(2)}</td><td class="num">${s.mean.toFixed(2)}</td><td class="num">${s.max.toFixed(2)}</td><td class="num"><strong>${current.toFixed(2)}</strong></td></tr>`;
}

function escape(s: string) {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
}
