// Offline predictive maintenance engine.
// Synthetic sensor dataset + lightweight logistic-style failure scoring.
// Everything runs in-browser, no network.

export type Equipment = {
  id: string;
  name: string;
  type: "Pump" | "Compressor" | "Turbine" | "Motor" | "Conveyor";
  installedYears: number;
};

export type Reading = {
  t: number; // hour index
  vibration: number; // mm/s
  temperature: number; // °C
  pressure: number; // bar
  rpm: number;
  current: number; // A
  oilQuality: number; // 0-100 (100 = fresh)
  runtimeHours: number;
};

export type Scored = Reading & { risk: number; label: 0 | 1 };

export type FeatureImportance = { feature: string; weight: number; contribution: number };

// Seeded PRNG (mulberry32) for deterministic offline data.
function rng(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const FLEET: Equipment[] = [
  { id: "PMP-01", name: "Coolant Pump A", type: "Pump", installedYears: 6 },
  { id: "CMP-02", name: "Air Compressor 2", type: "Compressor", installedYears: 3 },
  { id: "TRB-03", name: "Steam Turbine 3", type: "Turbine", installedYears: 9 },
  { id: "MTR-04", name: "Drive Motor 4", type: "Motor", installedYears: 2 },
  { id: "CNV-05", name: "Line Conveyor 5", type: "Conveyor", installedYears: 5 },
  { id: "PMP-06", name: "Hydraulic Pump 6", type: "Pump", installedYears: 8 },
];

// Baseline ranges per equipment type.
const BASE: Record<Equipment["type"], Omit<Reading, "t" | "runtimeHours">> = {
  Pump:       { vibration: 2.8, temperature: 62, pressure: 4.5, rpm: 1750, current: 18, oilQuality: 82 },
  Compressor: { vibration: 3.4, temperature: 71, pressure: 8.2, rpm: 1450, current: 26, oilQuality: 78 },
  Turbine:    { vibration: 4.1, temperature: 88, pressure: 12.0, rpm: 3200, current: 42, oilQuality: 74 },
  Motor:      { vibration: 2.2, temperature: 58, pressure: 1.2, rpm: 1780, current: 22, oilQuality: 88 },
  Conveyor:   { vibration: 1.9, temperature: 46, pressure: 0.8, rpm: 900, current: 12, oilQuality: 90 },
};

export function generateSeries(eq: Equipment, hours = 720, seed = 42): Reading[] {
  const rand = rng(seed + hashCode(eq.id));
  const base = BASE[eq.type];
  const wearRate = 0.00015 * (1 + eq.installedYears * 0.12);
  const data: Reading[] = [];
  let wear = eq.installedYears * 0.05;
  let oil = base.oilQuality - eq.installedYears * 1.6;

  // Inject a degradation episode randomly in second half.
  const degradeStart = Math.floor(hours * (0.55 + rand() * 0.35));
  const willFail = rand() > 0.35;

  for (let t = 0; t < hours; t++) {
    wear += wearRate + (t > degradeStart && willFail ? 0.0012 : 0);
    oil = Math.max(5, oil - 0.02 - (t > degradeStart && willFail ? 0.08 : 0));
    const noise = () => (rand() - 0.5) * 2;
    const spike = t > degradeStart && willFail ? (t - degradeStart) / (hours - degradeStart) : 0;

    data.push({
      t,
      runtimeHours: eq.installedYears * 8760 + t,
      vibration: +(base.vibration * (1 + wear) + noise() * 0.4 + spike * 5).toFixed(2),
      temperature: +(base.temperature + wear * 20 + noise() * 1.2 + spike * 18).toFixed(1),
      pressure: +(base.pressure * (1 - spike * 0.25) + noise() * 0.15).toFixed(2),
      rpm: Math.round(base.rpm * (1 - spike * 0.08) + noise() * 6),
      current: +(base.current * (1 + wear * 0.6) + noise() * 0.6 + spike * 4).toFixed(1),
      oilQuality: +Math.max(0, oil + noise() * 0.5).toFixed(1),
    });
  }
  return data;
}

function hashCode(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = ((h << 5) - h + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

// Logistic-style scorer with hand-tuned weights (approximates a trained model).
// Features normalized against expected operating envelope.
const WEIGHTS = {
  vibration: 1.35,
  temperature: 1.05,
  oilQuality: 1.55, // inverted (low oil quality = risk)
  current: 0.75,
  pressure: 0.55, // deviation
  rpm: 0.4,
} as const;

const BIAS = -3.6;

function sigmoid(x: number): number {
  return 1 / (1 + Math.exp(-x));
}

export function scoreReading(r: Reading, eq: Equipment): number {
  const b = BASE[eq.type];
  const nv = (r.vibration - b.vibration) / b.vibration;
  const nt = (r.temperature - b.temperature) / b.temperature;
  const no = (b.oilQuality - r.oilQuality) / b.oilQuality;
  const nc = (r.current - b.current) / b.current;
  const np = Math.abs(r.pressure - b.pressure) / b.pressure;
  const nr = Math.abs(r.rpm - b.rpm) / b.rpm;

  const z =
    BIAS +
    WEIGHTS.vibration * nv * 4 +
    WEIGHTS.temperature * nt * 4 +
    WEIGHTS.oilQuality * no * 3 +
    WEIGHTS.current * nc * 3 +
    WEIGHTS.pressure * np * 3 +
    WEIGHTS.rpm * nr * 3;

  return sigmoid(z);
}

export function scoreSeries(readings: Reading[], eq: Equipment): Scored[] {
  return readings.map((r) => {
    const risk = scoreReading(r, eq);
    return { ...r, risk, label: risk > 0.5 ? 1 : 0 };
  });
}

export function featureImportance(r: Reading, eq: Equipment): FeatureImportance[] {
  const b = BASE[eq.type];
  const parts: FeatureImportance[] = [
    { feature: "Vibration", weight: WEIGHTS.vibration, contribution: WEIGHTS.vibration * ((r.vibration - b.vibration) / b.vibration) * 4 },
    { feature: "Temperature", weight: WEIGHTS.temperature, contribution: WEIGHTS.temperature * ((r.temperature - b.temperature) / b.temperature) * 4 },
    { feature: "Oil Quality", weight: WEIGHTS.oilQuality, contribution: WEIGHTS.oilQuality * ((b.oilQuality - r.oilQuality) / b.oilQuality) * 3 },
    { feature: "Current Draw", weight: WEIGHTS.current, contribution: WEIGHTS.current * ((r.current - b.current) / b.current) * 3 },
    { feature: "Pressure Δ", weight: WEIGHTS.pressure, contribution: WEIGHTS.pressure * (Math.abs(r.pressure - b.pressure) / b.pressure) * 3 },
    { feature: "RPM Δ", weight: WEIGHTS.rpm, contribution: WEIGHTS.rpm * (Math.abs(r.rpm - b.rpm) / b.rpm) * 3 },
  ];
  return parts.sort((a, b) => b.contribution - a.contribution);
}

export type Forecast = { hour: number; risk: number };

// Simple exponential-trend forecast of risk over next N hours.
export function forecastRisk(scored: Scored[], horizon = 72): Forecast[] {
  const tail = scored.slice(-48);
  const n = tail.length;
  const xs = tail.map((_, i) => i);
  const ys = tail.map((r) => Math.log(Math.max(1e-4, r.risk)));
  const meanX = xs.reduce((a, b) => a + b, 0) / n;
  const meanY = ys.reduce((a, b) => a + b, 0) / n;
  const num = xs.reduce((s, x, i) => s + (x - meanX) * (ys[i] - meanY), 0);
  const den = xs.reduce((s, x) => s + (x - meanX) ** 2, 0) || 1;
  const slope = num / den;
  const intercept = meanY - slope * meanX;
  const start = scored[scored.length - 1]?.t ?? 0;

  return Array.from({ length: horizon }, (_, i) => {
    const x = n + i;
    const risk = Math.min(0.999, Math.exp(intercept + slope * x));
    return { hour: start + i + 1, risk };
  });
}

export function hoursToFailure(forecast: Forecast[], threshold = 0.8): number | null {
  const hit = forecast.find((f) => f.risk >= threshold);
  if (!hit) return null;
  return hit.hour - (forecast[0]?.hour ?? 0) + 1;
}

export function recommend(scored: Scored[], eq: Equipment): string[] {
  const last = scored[scored.length - 1];
  const imp = featureImportance(last, eq);
  const recs: string[] = [];
  const top = imp.filter((f) => f.contribution > 0.4).slice(0, 3);
  for (const f of top) {
    switch (f.feature) {
      case "Vibration": recs.push("Inspect bearings and shaft alignment; balance rotating assembly."); break;
      case "Temperature": recs.push("Check cooling loop and airflow; verify thermal sensors."); break;
      case "Oil Quality": recs.push("Schedule lubricant replacement and filter change within 48h."); break;
      case "Current Draw": recs.push("Review load profile and inspect winding insulation."); break;
      case "Pressure Δ": recs.push("Check seals, valves, and downstream pressure regulation."); break;
      case "RPM Δ": recs.push("Recalibrate drive controller and verify tachometer feedback."); break;
    }
  }
  if (last.risk < 0.35) recs.push("Continue standard monitoring cadence. No immediate action required.");
  return recs;
}
